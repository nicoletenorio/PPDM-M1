if ('serviceWorker' in navigator) {
    navigator.serviceWorker
      .register('sw.js', {scope: '/App/'})
      .then(serviceWorker => {
        console.log('Service Worker registered: ' + serviceWorker.scope);
      })
      .catch(error => {
        console.log('Error registering the Service Worker: ' + error);
      });
  }